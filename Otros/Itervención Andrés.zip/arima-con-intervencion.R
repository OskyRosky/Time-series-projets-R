# Cargamos los paquetes que ocupamos

library(forecast)
library(astsa)
library(ggplot2)
library(strucchange)

# Cargamos los datos

gasto_publico <- read.csv2("gastos_gobierno.csv")

# Deflatamos los gastos

gasto_publico$monto_real <- gasto_publico$gasto * 100 / gasto_publico$ipc

# Definimos la serie de tiempo, con la serie de entrenamiento y prueba

datos.ts <- ts(gasto_publico$monto_real, start = c(2007, 1), end = c(2018, 6), frequency = 12)

datos.entrenamiento <- ts(data = gasto_publico$monto_real[1:114], start = c(2007, 1), frequency = 12)
datos.prueba <- ts(data = gasto_publico$monto_real[115:138], end = c(2018, 6), frequency = 12)

# Ponemos el tema para ggplot

theme_set(theme_bw())

# Definimos los puntos de quiebre y graficamos el BIC contra el RSS

bs <- breakpoints(datos.ts ~ 1)
plot(bs)

# Graficamos las intervenciones en la serie

plot(datos.ts)
lines(fitted(bs, breaks = 2), col = 4)
lines(confint(bs, breaks = 2))

# También se puede hacer en ggplot

autoplot(datos.ts) + autolayer(fitted(bs))

# Definimos una nueva variable como factor, que es 0 cuando no ha pasado la 
# primer intervención, 1 entre la primera y la segunda y 2 después de la
# segunda

f <- factor(c(rep(0, bs$breakpoints[1]), 
              rep(1, bs$breakpoints[2] - bs$breakpoints[1]),
              rep(2, length(datos.ts) - bs$breakpoints[2])))

# Ya que xreg necesita ser una matriz, vamos a convertir el factor en una matriz
# de 1's y 0's mediante el comando model.matrix

nivel <- model.matrix(~f)[, -1]

# Agregamos la variable de nivel al modelo arima

ar.inter <- Arima(datos.entrenamiento, order = c(0, 1, 1), seasonal = c(2, 1, 0), xreg = nivel[1:114, ])
summary(ar.inter)

# Tenemos el modelo con intervención listo y podemos graficarlo

autoplot(datos.entrenamiento) + autolayer(fitted(ar.inter))
