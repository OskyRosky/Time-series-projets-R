#=======================================================================================================#
#Examen 3 
#Series de tiempo
#Geannina Barrantes y Mariana Chaves 
#=======================================================================================================#

#=======================================================================================================#
# ----PAQUETES-----
#=======================================================================================================#
setwd("C:/Users/maria/OneDrive/Documentos/UCR maestría/Semestre I/Series de tiempo/Examen 3")

library(readxl)
library(highcharter)
library(ggplot2)
library(greybox)
library(gridExtra)
library(DT)
library(devtools)

#=======================================================================================================#
# ----Pregunta II-----
#=======================================================================================================#
set.seed(8457)
sim1<-arima.sim(model=list(ar=0.9,ma=0.8),n=50)+100
set.seed(8457)
sim2<-arima.sim(model=list(ar=0.9,ma=0.8),n=100)+100 
set.seed(8457)
sim3<-arima.sim(model=list(ar=0.9,ma=0.8),n=200)+100
set.seed(8457)
sim4<-arima.sim(model=list(ar=0.9,ma=0.8),n=500)+100
set.seed(8457)
sim5<-arima.sim(model=list(ar=0.9,ma=0.8),n=1000)+100

sim=list(
  sim1=sim1,
  sim2=sim2,
  sim3=sim3,
  sim4=sim4,
  sim5=sim5
)

#Modelos con los datos de entrenamiento
modsim1=nnetar(sim1[1:(50*0.9)])
modsim2=nnetar(sim2[1:(100*0.9)])
modsim3=nnetar(sim3[1:(200*0.9)])
modsim4=nnetar(sim4[1:(500*0.9)])
modsim5=nnetar(sim5[1:(1000*0.9)])

#Medidas de rendimiento - entrenamiento
trainsim=rbind(
  accuracy(modsim1)[c(2,3,5)],
  accuracy(modsim2)[c(2,3,5)],
  accuracy(modsim3)[c(2,3,5)],
  accuracy(modsim4)[c(2,3,5)],
  accuracy(modsim5)[c(2,3,5)]
)
trainsim=as.data.frame(trainsim)
names(trainsim)=c("RMSE","MAE","MAPE")

#Medidas de rendimiento - validación

forecastsim=list()
forecastsim[[1]]=forecast(modsim1,h=(50*0.1))
forecastsim[[2]]=forecast(modsim2,h=(100*0.1))
forecastsim[[3]]=forecast(modsim3,h=(200*0.1))
forecastsim[[4]]=forecast(modsim4,h=(500*0.1))
forecastsim[[5]]=forecast(modsim5,h=(1000*0.1))

RMSEsim=c()
MAEsim=c()
MAPEsim=c()

for (i in 1:length(forecastsim)){
  fit=as.data.frame(forecastsim[[i]])$`Point Forecast`
  n=length(sim[[i]])
  start=n-n*0.1+1
  act=sim[[i]][start:n]
  #RMSE
  RMSEsim[i]=sqrt(sum((act-fit)^2)/n)
  #MAE
  MAEsim[i]=sum(abs(act-fit))/n
  #MAPE
  MAPEsim[i]=sum(abs(act-fit)/act)/n*100 
}

testsim=cbind(
  RMSEsim,
  MAEsim,
  MAPEsim
)
testsim=as.data.frame(testsim)
names(testsim)=c("RMSE","MAE","MAPE")

hsim1=hchart(forecast(modsim1,h=(50*0.1)))%>%
  hc_add_series(sim1,name="Datos de validación")%>%
  hc_title(text="T=50")
hsim1$x$hc_opts$series[[1]]$name="Datos de entrenamiento"
hsim1

hsim2=hchart(forecast(modsim2,h=(100*0.1)))%>%
hc_add_series(sim2,name="Datos de validación")%>%
  hc_title(text="T=100")
hsim2$x$hc_opts$series[[1]]$name="Datos de entrenamiento"
hsim2

hsim3=hchart(forecast(modsim3,h=(200*0.1)))%>%
  hc_add_series(sim3,name="Datos de validación")%>%
  hc_title(text="T=200")
hsim3$x$hc_opts$series[[1]]$name="Datos de entrenamiento"
hsim3

hsim4=hchart(forecast(modsim4,h=(500*0.1)))%>%
  hc_add_series(sim4,name="Datos de validación")%>%
  hc_title(text="T=500")
hsim4$x$hc_opts$series[[1]]$name="Datos de entrenamiento"
hsim4

hsim5=hchart(forecast(modsim5,h=(1000*0.1)))%>%
  hc_add_series(sim5,name="Datos de validación")%>%
  hc_title(text="T=1000")
hsim5$x$hc_opts$series[[1]]$name="Datos de entrenamiento"
hsim5

#=======================================================================================================#
# ----Pregunta III-----
#=======================================================================================================#

#=======================================================================================================#
# ----Datos-----
#=======================================================================================================#


datos=read_excel("Datos examen3.xlsx",sheet = 1)

#Deflactar 
datos$trans_defl=datos$`Transferencias Corrientes`*100/datos$IPC

#=======================================================================================================#
# ----PARTICIÓN DE LA SERIE----
#=======================================================================================================#
##Particiones en entrenamiento y validación
trans_ts <- ts(datos$trans_defl, start = c(2007,1), frequency = 12)
train.db <- datos [-((length(datos$trans_defl) - 23):length(datos$trans_defl)),]
test.db <- datos [((length(datos$trans_defl) - 23):length(datos$trans_defl)),]
ts.train <- ts(train.db$trans_defl, start = c(2007,01), frequency = 12)
ts.test <- ts(test.db$trans_defl, start = c(2016,07), frequency = 12)

#========================================#
# -------- Descripción de la serie --------
#========================================#
hchart(trans_ts, name="Transacciones corrientes reales")%>%
  hc_title(text = "Transferencias corrientes en el sector público de Costa Rica")

STLdesco=stl(trans_ts,t.window=13, s.window="periodic", robust=TRUE)
h=hchart(STLdesco)%>%
  hc_title(text = "Descomposición STL de las transacciones corrientes reales")
h$x$hc_opts$series[[1]]$name="Transferencias corrientes reales"
h$x$hc_opts$series[[2]]$name="Estacionalidad"
h$x$hc_opts$series[[3]]$name="Tendencia"
h$x$hc_opts$series[[4]]$name="Irregularidades"
h

#Serie aditiva
#tendencia creciente
#Valores aumentan en diciembre. Meses mas bajos junio y agosto
#Valores extremos en marzo de 2009, diciembre de 2009, diciembre 2013, julio 2013, octubre 2017, diciembre 2017, y otros...

#========================================#
# -------- Estacionaridad --------
#========================================#
hchart(trans_ts)
#La serie no es estacionaria, tiene clara tendencia creciente y posee patrones estacionales
ndiffs(trans_ts)
#Se confirma que no es estacionaria

#diferenciación de orden 1 
trans_ts2=diff(trans_ts)
hchart(trans_ts2)

#diferenciación de orden 12 
trans_ts3=diff(trans_ts2,lag=12)
hchart(trans_ts3)
ndiffs(trans_ts3)
#ya se ve estacionaria


#grafico consolidado

d0<-  autoplot(trans_ts) + xlab("Fecha") + ylab("MM de colones reales") +
  ggtitle("Transferencias corrientes en el sector público de Costa Rica") +
  geom_line(aes(group=1), colour="darkblue") +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"), text = element_text(size=9))


d2<-  autoplot(trans_ts2) + xlab("Fecha") + ylab("MM de colones reales") +
  ggtitle("Transferencias corrientes en el sector público de Costa Rica con una diferenciación de orden 1") +
  geom_line(aes(group=1), colour="darkblue") +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"), text = element_text(size=9))

d3<-  autoplot(trans_ts3) + xlab("Fecha") + ylab("MM de colones reales") +
  ggtitle("Transferencias corrientes en el sector público de Costa Rica con una diferenciación de orden 1 y de orden 12") +
  geom_line(aes(group=1), colour="darkblue") +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"), text = element_text(size=9))


grid.arrange(d0, d2, d3, nrow = 4, top = "Estacionarización de la serie Transferencias corrientes en el sector público de Costa Rica")

est=hchart(cbind(trans_ts,trans_ts2,trans_ts3))%>%
  hc_title(text = "Transferencias corrientes en el sector público de Costa Rica con una diferenciación de orden 1 y de orden 12")
est$x$hc_opts$series[[1]]$name="Transferencias corrientes reales"
est$x$hc_opts$series[[2]]$name="Diferenciación de orden 1"
est$x$hc_opts$series[[3]]$name="Diferenciación de orden 1 y 12"
est

#=============================================#
# -------- Identificación del modelo --------
#=============================================#

acf2(trans_ts2,main="Autocorrelación total y parcial", xlab="Rezagos")

#La autocorrelación total decae rápidamente después del primer rezago, mientras que la autocorrelación parcial decae de manera más lenta
#por lo que se sospecha de un modelo MA1

#La autocorrelación total decae lentamente para los rezagos 12,24,36 y 48, mientras que la autocorrelación parcial es casi nula. 
#Se sospecha de un proceso AR en la parte estacional

#=============================================#
# -------- Modelos Arima --------
#=============================================#

#Sin parte estacional 0,1,0
modarima.a1=Arima(ts.train, order=c(0,1,1), seasonal=c(0,1,0))
modarima.a2=Arima(ts.train, order=c(0,1,2), seasonal=c(0,1,0))
modarima.a3=Arima(ts.train, order=c(1,1,0), seasonal=c(0,1,0))
modarima.a4=Arima(ts.train, order=c(1,1,1), seasonal=c(0,1,0))
modarima.a5=Arima(ts.train, order=c(1,1,2), seasonal=c(0,1,0))
modarima.a6=Arima(ts.train, order=c(2,1,0), seasonal=c(0,1,0))
modarima.a7=Arima(ts.train, order=c(2,1,1), seasonal=c(0,1,0))
modarima.a8=Arima(ts.train, order=c(2,1,2), seasonal=c(0,1,0))

#Parte estacional MA 1 
modarima.b1=Arima(ts.train, order=c(0,1,1), seasonal=c(0,1,1))
modarima.b2=Arima(ts.train, order=c(0,1,2), seasonal=c(0,1,1))
modarima.b3=Arima(ts.train, order=c(1,1,0), seasonal=c(0,1,1))
modarima.b4=Arima(ts.train, order=c(1,1,1), seasonal=c(0,1,1))
modarima.b5=Arima(ts.train, order=c(1,1,2), seasonal=c(0,1,1))
modarima.b6=Arima(ts.train, order=c(2,1,0), seasonal=c(0,1,1))
modarima.b7=Arima(ts.train, order=c(2,1,1), seasonal=c(0,1,1))
modarima.b8=Arima(ts.train, order=c(2,1,2), seasonal=c(0,1,1))

##Parte estacional MA 2
modarima.c1=Arima(ts.train, order=c(0,1,1), seasonal=c(0,1,2))
modarima.c2=Arima(ts.train, order=c(0,1,2), seasonal=c(0,1,2))
modarima.c3=Arima(ts.train, order=c(1,1,0), seasonal=c(0,1,2))
modarima.c4=Arima(ts.train, order=c(1,1,1), seasonal=c(0,1,2))
modarima.c5=Arima(ts.train, order=c(1,1,2), seasonal=c(0,1,2))
modarima.c6=Arima(ts.train, order=c(2,1,0), seasonal=c(0,1,2))
modarima.c7=Arima(ts.train, order=c(2,1,1), seasonal=c(0,1,2))
modarima.c8=Arima(ts.train, order=c(2,1,2), seasonal=c(0,1,2))

#Parte estacional AR 1 
modarima.d1=Arima(ts.train, order=c(0,1,1), seasonal=c(1,1,0))
modarima.d2=Arima(ts.train, order=c(0,1,2), seasonal=c(1,1,0))
modarima.d3=Arima(ts.train, order=c(1,1,0), seasonal=c(1,1,0))
modarima.d4=Arima(ts.train, order=c(1,1,1), seasonal=c(1,1,0))
modarima.d5=Arima(ts.train, order=c(1,1,2), seasonal=c(1,1,0))
modarima.d6=Arima(ts.train, order=c(2,1,0), seasonal=c(1,1,0))
modarima.d7=Arima(ts.train, order=c(2,1,1), seasonal=c(1,1,0))
modarima.d8=Arima(ts.train, order=c(2,1,2), seasonal=c(1,1,0))

#Parte estacional AR 2
modarima.e1=Arima(ts.train, order=c(0,1,1), seasonal=c(2,1,0))
modarima.e2=Arima(ts.train, order=c(0,1,2), seasonal=c(2,1,0))
modarima.e3=Arima(ts.train, order=c(1,1,0), seasonal=c(2,1,0))
modarima.e4=Arima(ts.train, order=c(1,1,1), seasonal=c(2,1,0))
modarima.e5=Arima(ts.train, order=c(1,1,2), seasonal=c(2,1,0))
modarima.e6=Arima(ts.train, order=c(2,1,0), seasonal=c(2,1,0))
modarima.e7=Arima(ts.train, order=c(2,1,1), seasonal=c(2,1,0))
modarima.e8=Arima(ts.train, order=c(2,1,2), seasonal=c(2,1,0))

#Parte estacional ARMA 1,1 
modarima.f1=Arima(ts.train, order=c(0,1,1), seasonal=c(1,1,1))
modarima.f2=Arima(ts.train, order=c(0,1,2), seasonal=c(1,1,1))
modarima.f3=Arima(ts.train, order=c(1,1,0), seasonal=c(1,1,1))
modarima.f4=Arima(ts.train, order=c(1,1,1), seasonal=c(1,1,1))
modarima.f5=Arima(ts.train, order=c(1,1,2), seasonal=c(1,1,1))
modarima.f6=Arima(ts.train, order=c(2,1,0), seasonal=c(1,1,1))
modarima.f7=Arima(ts.train, order=c(2,1,1), seasonal=c(1,1,1))
modarima.f8=Arima(ts.train, order=c(2,1,2), seasonal=c(1,1,1))

#Parte estacional ARMA 1,2
modarima.g1=Arima(ts.train, order=c(0,1,1), seasonal=c(1,1,2))
modarima.g2=Arima(ts.train, order=c(0,1,2), seasonal=c(1,1,2))
modarima.g3=Arima(ts.train, order=c(1,1,0), seasonal=c(1,1,2))
modarima.g4=Arima(ts.train, order=c(1,1,1), seasonal=c(1,1,2))
modarima.g5=Arima(ts.train, order=c(1,1,2), seasonal=c(1,1,2))
modarima.g6=Arima(ts.train, order=c(2,1,0), seasonal=c(1,1,2))
modarima.g7=Arima(ts.train, order=c(2,1,1), seasonal=c(1,1,2))
modarima.g8=Arima(ts.train, order=c(2,1,2), seasonal=c(1,1,2))

#Parte estacional AR 2,1 
modarima.h1=Arima(ts.train, order=c(0,1,1), seasonal=c(2,1,1))
modarima.h2=Arima(ts.train, order=c(0,1,2), seasonal=c(2,1,1))
modarima.h3=Arima(ts.train, order=c(1,1,0), seasonal=c(2,1,1))
modarima.h4=Arima(ts.train, order=c(1,1,1), seasonal=c(2,1,1))
modarima.h5=Arima(ts.train, order=c(1,1,2), seasonal=c(2,1,1))
modarima.h6=Arima(ts.train, order=c(2,1,0), seasonal=c(2,1,1))
modarima.h7=Arima(ts.train, order=c(2,1,1), seasonal=c(2,1,1))
modarima.h8=Arima(ts.train, order=c(2,1,2), seasonal=c(2,1,1))

#Parte estacional AR 2,2
modarima.i1=Arima(ts.train, order=c(0,1,1), seasonal=c(2,1,2))
modarima.i2=Arima(ts.train, order=c(0,1,2), seasonal=c(2,1,2))
modarima.i3=Arima(ts.train, order=c(1,1,0), seasonal=c(2,1,2))
modarima.i4=Arima(ts.train, order=c(1,1,1), seasonal=c(2,1,2))
modarima.i5=Arima(ts.train, order=c(1,1,2), seasonal=c(2,1,2))
modarima.i6=Arima(ts.train, order=c(2,1,0), seasonal=c(2,1,2))
modarima.i7=Arima(ts.train, order=c(2,1,1), seasonal=c(2,1,2))
modarima.i8=Arima(ts.train, order=c(2,1,2), seasonal=c(2,1,2))

#Autoarima
modautoarima=auto.arima(ts.train)

#Escoger el mejor modelo arima

listmodels.arima=list(
  modarima.a1=modarima.a1,
  modarima.a2=modarima.a2,
  modarima.a3=modarima.a3,
  modarima.a4=modarima.a4,
  modarima.a5=modarima.a5,
  modarima.a6=modarima.a6,
  modarima.a7=modarima.a7,
  modarima.a8=modarima.a8,
  
  modarima.b1=modarima.b1,
  modarima.b2=modarima.b2,
  modarima.b3=modarima.b3,
  modarima.b4=modarima.b4,
  modarima.b5=modarima.b5,
  modarima.b6=modarima.b6,
  modarima.b7=modarima.b7,
  modarima.b8=modarima.b8,
  
  modarima.c1=modarima.c1,
  modarima.c2=modarima.c2,
  modarima.c3=modarima.c3,
  modarima.c4=modarima.c4,
  modarima.c5=modarima.c5,
  modarima.c6=modarima.c6,
  modarima.c7=modarima.c7,
  modarima.c8=modarima.c8,
  
  modarima.d1=modarima.d1,
  modarima.d2=modarima.d2,
  modarima.d3=modarima.d3,
  modarima.d4=modarima.d4,
  modarima.d5=modarima.d5,
  modarima.d6=modarima.d6,
  modarima.d7=modarima.d7,
  modarima.d8=modarima.d8,
  
  modarima.e1=modarima.e1,
  modarima.e2=modarima.e2,
  modarima.e3=modarima.e3,
  modarima.e4=modarima.e4,
  modarima.e5=modarima.e5,
  modarima.e6=modarima.e6,
  modarima.e7=modarima.e7,
  modarima.e8=modarima.e8,
  
  modarima.f1=modarima.f1,
  modarima.f2=modarima.f2,
  modarima.f3=modarima.f3,
  modarima.f4=modarima.f4,
  modarima.f5=modarima.f5,
  modarima.f6=modarima.f6,
  modarima.f7=modarima.f7,
  modarima.f8=modarima.f8,
  
  modarima.g1=modarima.g1,
  modarima.g2=modarima.g2,
  modarima.g3=modarima.g3,
  modarima.g4=modarima.g4,
  modarima.g5=modarima.g5,
  modarima.g6=modarima.g6,
  modarima.g7=modarima.g7,
  modarima.g8=modarima.g8,
  
  modarima.h1=modarima.h1,
  modarima.h2=modarima.h2,
  modarima.h3=modarima.h3,
  modarima.h4=modarima.h4,
  modarima.h5=modarima.h5,
  modarima.h6=modarima.h6,
  modarima.h7=modarima.h7,
  #modarima.h8=modarima.h8,
  
  modarima.i1=modarima.i1,
  modarima.i2=modarima.i2,
  modarima.i3=modarima.i3,
  modarima.i4=modarima.i4,
  modarima.i5=modarima.i5,
  modarima.i6=modarima.i6,
  #modarima.i7=modarima.i7,
  modarima.i8=modarima.i8,
  
  modautoarima=modautoarima
)

#Para los datos de entrenamiento
AIC=c()
BIC=c()
AICC=c()
RMSE=c()
MAE=c()
MAPE=c()

for (i in 1:length(listmodels.arima)){
  #Criterios de informacion
  AIC[i]=AIC(listmodels.arima[[i]])  
  BIC[i]=BIC(listmodels.arima[[i]])
  AICC[i]=AICc(listmodels.arima[[i]])
  #Medidas clasicas
  RMSE[i]=accuracy(listmodels.arima[[i]])[2]
  MAE[i]=accuracy(listmodels.arima[[i]])[3]
  MAPE[i]=accuracy(listmodels.arima[[i]])[5]  
}

#Estimaciones para los datos de forecast
listforecast.arima=list()
for (i in 1:length(listmodels.arima)){
  listforecast.arima[[i]]=forecast(listmodels.arima[[i]],h=24)
  names(listforecast.arima)[i]=paste(names(listmodels.arima)[i],'fcst',sep='')
}

RMSE2=c()
MAE2=c()
MAPE2=c()

for (i in 1:length(listforecast.arima)){
  a=as.data.frame(summary(listforecast.arima[[i]])[1])
  fit=a$`Point Forecast`
  act=test.db$trans_defl
  n=length(act)
  #RMSE
  RMSE2[i]=sqrt(sum((act-fit)^2)/n)
  #MAE
  MAE2[i]=sum(abs(act-fit))/n
  #MAPE
  MAPE2[i]=sum(abs(act-fit)/act)/n*100 
}

#Selección del mejor de regresión
train.metrics=as.data.frame(round(cbind(AIC,BIC,AICC,RMSE,MAE,MAPE),2))
train.metrics$model=names(listmodels.arima)
best.positions.train=apply(train.metrics[-length(train.metrics)],2,which.min)
train.metrics$model[best.positions.train] 
train.metrics
#Gana el modelo b1, y b4 en segundo lugar, g5

test.metrics=as.data.frame(round(cbind(RMSE2,MAE2,MAPE2),2))
test.metrics$model=names(listmodels.arima)
best.positions.test=apply(test.metrics[-length(test.metrics)],2,which.min)
test.metrics$model[best.positions.test] 
test.metrics
#en testing gana d5, seguido de d8

#Se escoge el modelo d5 por ser mejor modelo en la parte de validación, 
#además de que sigue en parte la estructura identificada con los correlogramas. 
sarima(ts.train,p=1,d=1,q=2,P=1,D=1,Q=0,S=12)
#Cumple satisfactoriamente los supuestos. Excepto el de normalidad. 

#=============================================#
# -------- Modelo de redes neuronales --------
#=============================================#

set.seed(857)
mod.nn=nnetar(ts.train)

source_url('https://gist.githubusercontent.com/fawda123/7471137/raw/466c1474d0a505ff044412703516c34f1a4684a5/nnet_plot_update.r')

mod.nn$p
mod.nn$P

wts.in<-mod.nn$model[[1]]$wts
struct<-mod.nn$model[[1]]$n
input.names=c('Regazo 1','Rezago 2','Rezago 12')
plot.nnet(wts.in,struct=struct,
          pos.col='#5B9BD5',
          neg.col='#FFC000',
          circle.col=list('#ED7D31','lightblue'),
          x.lab = input.names)


#=============================================#
# -------- Medidas de rendimiento --------
#=============================================#

#Solo se calcularon las clásicas puesto que no es posible calcular AIC y BIC para redes

accuracy(mod.nn)
accuracy(modarima.d5)

listmodels=list(
  modarima.d5=modarima.d5,
  mod.nn=mod.nn
)

#Para los datos de entrenamiento
RMSE=c()
MAE=c()
MAPE=c()

for (i in 1:length(listmodels)){
  #Medidas clasicas
  RMSE[i]=accuracy(listmodels[[i]])[2]
  MAE[i]=accuracy(listmodels[[i]])[3]
  MAPE[i]=accuracy(listmodels[[i]])[5]  
}

#Estimaciones para los datos de forecast
listforecast=list()
listforecast[[1]]=forecast(listmodels[[1]],h=24)
listforecast[[2]]=forecast(listmodels[[2]],h=24,PI=TRUE)

RMSE2=c()
MAE2=c()
MAPE2=c()

for (i in 1:length(listforecast)){
  a=as.data.frame(summary(listforecast[[i]])[1])
  fit=a$`Point Forecast`
  act=test.db$trans_defl
  n=length(act)
  #RMSE
  RMSE2[i]=sqrt(sum((act-fit)^2)/n)
  #MAE
  MAE2[i]=sum(abs(act-fit))/n
  #MAPE
  MAPE2[i]=sum(abs(act-fit)/act)/n*100 
}

#Selección del mejor modelo
train.metrics=as.data.frame(round(cbind(RMSE,MAE,MAPE),2))
train.metrics$model=names(listmodels)
best.positions.train=apply(train.metrics[-length(train.metrics)],2,which.min)
train.metrics$model[best.positions.train] 
train.metrics
#Gana el arima por muy pocos puntos

test.metrics=as.data.frame(round(cbind(RMSE2,MAE2,MAPE2),2))
test.metrics$model=names(listmodels)
best.positions.test=apply(test.metrics[-length(test.metrics)],2,which.min)
test.metrics$model[best.positions.test] 
test.metrics
#Gana el arima


#=============================================#
# -------- Pronósticos --------
#=============================================#

mod.arima.final=Arima(trans_ts, order=c(1,1,2), seasonal=c(1,1,0))
mod.nn.final=nnetar(trans_ts)

#Pronóstico del IPC
datos.IPC=ts(datos$IPC, start = c(2007,1), frequency = 12)
ipc_ts <- ts(datos.IPC, start = c(2007,1), frequency = 12)
modIPC=tslm(datos.IPC~trend+season, data=datos.IPC)
forecast.ipc=forecast(modIPC,h=24)$mean


#Valores nominales
trans.nominales=ts(datos$`Transferencias Corrientes`, start = c(2007,1), frequency = 12)

forecast.arima=forecast(mod.arima.final,level=95,h=24)
f.arima.mean=forecast.arima$mean*forecast.ipc/100
f.arima.lower=forecast.arima$lower*forecast.ipc/100
f.arima.upper=forecast.arima$upper*forecast.ipc/100
forecast.arima2=forecast.arima
forecast.arima2$mean=f.arima.mean
forecast.arima2$lower=f.arima.lower
forecast.arima2$upper=f.arima.upper
forecast.arima2$x=trans.nominales

fitted.arima=mod.arima.final$fitted*datos$IPC/100

h1=hchart(forecast.arima2)%>% 
  hc_add_series(fitted.arima,name="Valores justados")%>%
  hc_title(text="Transacciones corrientes, valores ajustados, y pronósticos con el modelo ARIMA")
h1$x$hc_opts$series[[1]]$name="Transferencias corrinetes"
h1$x$hc_opts$series[[2]]$name="Pronósticos"
h1$x$hc_opts$series[[3]]$fillOpacity=0.5
h1

forecast.nn=forecast(mod.nn.final,PI=TRUE,h=24,level=95)
f.nn.mean=forecast.nn$mean*forecast.ipc/100
f.nn.lower=forecast.nn$lower*forecast.ipc/100
f.nn.upper=forecast.nn$upper*forecast.ipc/100
forecast.nn2=forecast.nn
forecast.nn2$mean=f.nn.mean
forecast.nn2$lower=f.nn.lower
forecast.nn2$upper=f.nn.upper
forecast.nn2$x=trans.nominales

fitted.nn=mod.nn.final$fitted*datos$IPC/100

h2=hchart(forecast.nn2)%>% 
  hc_add_series(fitted.nn,name="Valores justados")%>%
  hc_title(text="Transacciones corrientes, valores ajustados, y pronósticos con el modelo de redes neuronales")
h2$x$hc_opts$series[[1]]$name="Transferencias corrinetes"
h2$x$hc_opts$series[[2]]$name="Pronósticos"
h2$x$hc_opts$series[[3]]$fillOpacity=0.4
h2

#Para las tablas de pronósticos
a1=as.data.frame(forecast.arima2)
a2=as.data.frame(forecast.nn2)

#Análisis del cambio porcentual: ver excel


#=============================================#
# -------- Partición distinta --------
#=============================================#

##Particiones en entrenamiento y validación
mitad=round(length(datos$trans_defl)/2)
time(trans_ts)[mitad+1]

train.db5050 <- datos [1:mitad,]
test.db5050 <- datos [(mitad+1):length(datos$trans_defl),]
ts.train5050 <- ts(train.db5050$trans_defl, start = c(2007,01), frequency = 12)
ts.test5050 <- ts(test.db5050$trans_defl, start = c(2012,10), frequency = 12)

mod.arima.5050=Arima(ts.train5050, order=c(1,1,2), seasonal=c(1,1,0))
mod.nn.5050=nnetar(ts.train5050)

listmodels5050=list(
  mod.arima.5050=mod.arima.5050,
  mod.nn.5050=mod.nn.5050
)

#Para los datos de entrenamiento
RMSE=c()
MAE=c()
MAPE=c()

for (i in 1:length(listmodels5050)){
  #Medidas clasicas
  RMSE[i]=accuracy(listmodels5050[[i]])[2]
  MAE[i]=accuracy(listmodels5050[[i]])[3]
  MAPE[i]=accuracy(listmodels5050[[i]])[5]  
}

#Estimaciones para los datos de forecast
listforecast=list()
listforecast[[1]]=forecast(listmodels5050[[1]],h=mitad)
listforecast[[2]]=forecast(listmodels5050[[2]],h=mitad,PI=TRUE)

RMSE2=c()
MAE2=c()
MAPE2=c()

for (i in 1:length(listforecast)){
  a=as.data.frame(summary(listforecast[[i]])[1])
  fit=a$`Point Forecast`
  act=test.db5050$trans_defl
  n=length(act)
  #RMSE
  RMSE2[i]=sqrt(sum((act-fit)^2)/n)
  #MAE
  MAE2[i]=sum(abs(act-fit))/n
  #MAPE
  MAPE2[i]=sum(abs(act-fit)/act)/n*100 
}

#Selección del mejor modelo
train.metrics=as.data.frame(round(cbind(RMSE,MAE,MAPE),2))
train.metrics$model=names(listmodels5050)
best.positions.train=apply(train.metrics[-length(train.metrics)],2,which.min)
train.metrics$model[best.positions.train] 
train.metrics
#Ahora gana la red
AIC(mod.arima.5050)
BIC(mod.arima.5050)
AICc(mod.arima.5050)

test.metrics=as.data.frame(round(cbind(RMSE2,MAE2,MAPE2),2))
test.metrics$model=names(listmodels5050)
best.positions.test=apply(test.metrics[-length(test.metrics)],2,which.min)
test.metrics$model[best.positions.test] 
test.metrics
#Sigue ganando el arima

#A la red la afecta la cantidad de muestra, por eso su poder predictivo en este caso no es tan bueno. 
